---
title: BRIA RMBG 1.4
emoji: 💻
colorFrom: red
colorTo: red
sdk: gradio
sdk_version: 4.16.0
app_file: app.py
pinned: false
license: other
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
